.. jpy documentation master file, created by
   sphinx-quickstart on Mon Jan 20 21:26:19 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to jpy's documentation!
===============================

jpy is a *bi-directional* Java-Python bridge allowing you to call Java from Python and Python from Java.

Contents:

.. toctree::
   :maxdepth: 2
   
   intro
   install
   tutorial
   reference
   modify


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

