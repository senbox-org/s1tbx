# Created by 'jpyutil.py' tool on 2015-09-10 16:57:46.422000
# This file is read by the 'jpyutil' module in order to load and configure the JVM from Python
java_home = 'C:\\Program Files (x86)\\Java\\jdk1.8.0_60'
jvm_dll = 'C:\\Program Files (x86)\\Java\\jdk1.8.0_60\\jre\\bin\\server\\jvm.dll'
jvm_maxmem = None
jvm_classpath = []
jvm_properties = {}
jvm_options = []
