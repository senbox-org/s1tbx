# Created by 'jpyutil.py' tool on 2018-02-08 14:00:44.766303
# This file is read by the 'jpyutil' module in order to load and configure the JVM from Python
java_home = '/usr/lib/jvm/java-8-oracle'
jvm_dll = '/usr/lib/jvm/java-8-oracle/jre/lib/amd64/server/libjvm.so'
jvm_maxmem = None
jvm_classpath = []
jvm_properties = {}
jvm_options = []
