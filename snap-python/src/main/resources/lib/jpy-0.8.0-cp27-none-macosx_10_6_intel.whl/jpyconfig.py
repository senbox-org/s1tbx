# Created by 'jpyutil.py' tool on 2015-09-07 14:11:45.395606
# This file is read by the 'jpyutil' module in order to load and configure the JVM from Python
java_home = '/Library/Java/JavaVirtualMachines/jdk1.8.0_60.jdk/Contents/Home'
jvm_dll = '/Library/Java/JavaVirtualMachines/jdk1.8.0_60.jdk/Contents/Home/jre/lib/server/libjvm.dylib'
jvm_maxmem = None
jvm_classpath = []
jvm_properties = {}
jvm_options = []
