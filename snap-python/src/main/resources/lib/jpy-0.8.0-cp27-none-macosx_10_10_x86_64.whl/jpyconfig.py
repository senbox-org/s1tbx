# Created by 'jpyutil.py' tool on 2015-10-14 18:21:56.248421
# This file is read by the 'jpyutil' module in order to load and configure the JVM from Python
java_home = '/Library/Java/JavaVirtualMachines/jdk1.8.0_45.jdk/Contents/Home'
jvm_dll = '/Library/Java/JavaVirtualMachines/jdk1.8.0_45.jdk/Contents/Home/jre/lib/server/libjvm.dylib'
jvm_maxmem = None
jvm_classpath = []
jvm_properties = {}
jvm_options = []
