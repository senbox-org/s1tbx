# Created by 'jpyutil.py' tool on 2015-08-20 17:07:30.443113
# This file is read by the 'jpyutil' module in order load and configure the JVM from Python
java_home = '/home/norman/Apps/jdk1.8.0_60'
jvm_dll = '/home/norman/Apps/jdk1.8.0_60/jre/lib/amd64/server/libjvm.so'
jvm_maxmem = None
jvm_classpath = []
jvm_properties = {}
jvm_options = []
