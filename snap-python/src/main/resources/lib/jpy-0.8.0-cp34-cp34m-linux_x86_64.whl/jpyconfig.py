# Created by 'jpyutil.py' tool on 2015-09-10 18:01:44.462682
# This file is read by the 'jpyutil' module in order to load and configure the JVM from Python
java_home = '/home/norman/Apps/jdk1.8.0_60'
jvm_dll = '/home/norman/Apps/jdk1.8.0_60/jre/lib/amd64/server/libjvm.so'
jvm_maxmem = None
jvm_classpath = []
jvm_properties = {}
jvm_options = []
