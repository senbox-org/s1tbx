# Created by 'jpyutil.py' tool on 2018-02-08 15:40:44.905212
# This file is read by the 'jpyutil' module in order to load and configure the JVM from Python
java_home = 'C:\\Program Files\\Java\\jdk1.8.0'
jvm_dll = 'C:\\Program Files\\Java\\jdk1.8.0\\jre\\bin\\server\\jvm.dll'
jvm_maxmem = None
jvm_classpath = []
jvm_properties = {}
jvm_options = []
